package com.example.myapplication.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "student_table")
public class Student {
    
    @PrimaryKey(autoGenerate = true)
    private int id;
    
    private String name;
    private String studentId;
    private int age;
    private String course;

    public Student(String name, String studentId, int age, String course) {
        this.name = name;
        this.studentId = studentId;
        this.age = age;
        this.course = course;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getStudentId() {
        return studentId;
    }

    public int getAge() {
        return age;
    }

    public String getCourse() {
        return course;
    }
}

